import logging
from py.device_dispenser_dt1000 import td1000

# Configuración de logging
logging.basicConfig(format="%(asctime)s [%(levelname)s] %(module)s:%(lineno)d: %(message)s", level=logging.DEBUG)

def iniciar_dispenser():
    logging.info("<----------------------- INICIANDO CARRO -------------------------->")
    dispenser = None
    try:
        dispenser = td1000()
        status = dispenser.start()
        if not status:
            logging.error("Fallo al iniciar el dispensador")
            return False
        logging.info("Dispensador iniciado correctamente")

        # Llamada a take_card() después de la inicialización correcta
        dispenser.dispense_card()
        logging.info("Tarjeta tomada correctamente")

        return True
    except Exception as e:
        logging.error(f"Excepción al iniciar el dispensador: {e}")
        return False
    finally:
        if dispenser:
            dispenser.close()

if __name__ == "__main__":
    iniciar_dispenser()
