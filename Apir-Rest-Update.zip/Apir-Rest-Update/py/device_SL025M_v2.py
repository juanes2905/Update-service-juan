

from time					import sleep
from typing					import Tuple
import serial

import threading

import logging
import sys
import glob

def serial_ports():
    """ Lists serial port names

        :raises EnvironmentError:
            On unsupported or unknown platforms
        :returns:
            A list of the serial ports available on the system
    """
    if sys.platform.startswith('win'):
        ports = ['COM%s' % (i + 1) for i in range(256)]
    elif sys.platform.startswith('linux') or sys.platform.startswith('cygwin'):
        # this excludes your current terminal "/dev/tty"
        ports = glob.glob('/dev/tty[A-Za-z]*')
    elif sys.platform.startswith('darwin'):
        ports = glob.glob('/dev/tty.*')
    else:
        raise EnvironmentError('Unsupported platform')

    result = []
    for port in ports:
        try:
            s = serial.Serial(port)
            s.close()
            result.append(port)
        except (OSError, serial.SerialException):
            pass
    return result

TYPES= {
    b'\x01' : 'Mifare 1k, 4 byte UID',
    b'\x02' : 'Mifare 1k, 7 byte UID',
    b'\x03' : 'Mifare UltraLight or NATG203, 7 byte UID',
    b'\x04' : 'Mifare 4k, 4 byte UID',
    b'\x05' : 'Mifare 4k, 7 byte UID',
    b'\x06' : 'Mifare DesFire, 7 byte UID',
    b'\x0A' : 'Other'}

class Lector_SL025:
	ser=None
	lastserial=None
	lock=threading.Lock()

	def __init__(self):
		logging.info(self.__class__.__name__)

	def start(self, port_serial, keytype, key, sector, bloque) -> None:
		logging.info(f"	port {port_serial} - keytype {keytype} - key {key} - sector {sector} - bloque {bloque}")

		self.port_serial	= port_serial
		self.keyType		= keytype
		self.key			= key
		self.sector			= sector
		self.bloque			= bloque

		self.getserialport(port_serial)
		logging.info(f"SL025 port:{self.ser}")



	def getserialport(self, port_serial: str) -> serial:
		if port_serial=="autodetect":
			ports = serial_ports()
		else:
			ports=[port_serial]
			if "/dev/" in port_serial:
				ports=ports+["/dev/ttyUSB0","/dev/ttyUSB1","/dev/ttyUSB2"]

		for port in ports:
			try:
				logging.info (f"Opening {port}")
				self.ser = serial.Serial(
					port		= port,
					baudrate	= 9600,
					parity		= serial.PARITY_NONE,
					stopbits	= serial.STOPBITS_ONE,
					bytesize	= serial.EIGHTBITS,
					timeout		= 0.2,
				)

				response	= self.sendcommand(bytearray(b'\xBA\x02\x01'))
				logging.info(f"{port} {response}")
				if response:
					if len(response)>0:
						if response[0]==0xbd:
							logging.info("CONEXION EXITOSA")
							return

			except Exception as e:
				logging.error(f"Error connecting to SL025: {e}")

		self.ser=None

	def start_scan(self, callback=None):
		logging.info(f"Last Card:{self.lastserial}")
		self.callback = callback
		self.scanning = True

		threading.Thread(target=self.scan).start()

	def stop_scan(self):
		self.scanning = False

	def scan(self):
		while self.scanning:
			id = self.select_card()
			if id:
				serial = -1
				if id[0]:
					if len(id) > 1: serial = id[1]
				if serial != self.lastserial:
					self.lastserial = serial
					self.callback({"class": "card", "data": id[1]})
			sleep(0.5)
		return

	def CRC(self, Data: bytes) -> bytes:
		lrc	= 0
		for v in Data:	lrc ^= v
		return	lrc

	def sendcommand(self, cmd:bytearray, value:list = None):

		if value:
			for k in value:	cmd.append(k)

		cmd.append(self.CRC(cmd))

		if self.ser:
			bytesToRead	= 0
			repCounter	= 0

			with self.lock:
				self.ser.write(cmd)
				sleep(0.1)
				repCounter=0
				while bytesToRead == 0 and repCounter < 10:
					sleep(.05)
					bytesToRead	= self.ser.inWaiting()
					repCounter=repCounter+1

				sleep(.05)

				bytesToRead		= self.ser.inWaiting()
				incommingBytes	= self.ser.read(bytesToRead)

			return	incommingBytes

		else:
			logging.error(f"No serial port. {self.ser}")

		return None

	def close(self):
		logging.info("CLOSE PORT")
		self.ser.close()
		sleep(1)

	def cleancommand(self, response_command, compare):
		init = response_command
		pos = 0
		for element in response_command:
			if hex(element) == compare:	break
			else:						pos += 1

		response_command = response_command[pos:]

		if init != response_command:	logging.info(response_command)

		return response_command

	def select_card(self, mode=0):
		try:
			response = (None, -1)
			response_command	= self.sendcommand(bytearray(b'\xBA\x02\x01'))
			if response_command==b"":
				sleep(0.1)
				response_command = self.sendcommand(bytearray(b'\xBA\x02\x01'))
			if response_command==b"": return response

			if hex(response_command[0]) == '0xbd':
				if  hex(response_command[3]) == '0x0':
					length		= response_command[1]
					ttype		= hex(response_command[length])
					uid			= response_command[4:length].hex()

					if mode == 0:
						response = ({'uid': uid}, int(uid[6:8] + uid[4:6] + uid[2:4] + uid[0:2], 16))
					else:
						response = ({'uid': uid, 'type': ttype, 'literalType': ttype}, 0)

		except Exception as err:
			logging.error(err)
			response=(None,-9)

		return response

	def loginSector(self) -> bool:
		response	= self.sendcommand(bytearray(b'\xBA\x0A\x02') + bytes.fromhex(self.sector) + bytes.fromhex(self.keyType) + bytes.fromhex(self.key))
		if len(response)<4:
			sleep(0.1)
			response = self.sendcommand(bytearray(b'\xBA\x0A\x02') + bytes.fromhex(self.sector) + bytes.fromhex(
				self.keyType) + bytes.fromhex(self.key))
		if len(response)<4: return False

		#response	= self.cleancommand(response, '0xbd')
		if hex(response[0]) == '0xbd':
			status	= hex(response[3])

			if status == '0x2': return True
			if status == '0x1': logging.info("No Card")
			if status == '0x3':
				logging.info("Logging invalid key")
				response	= self.sendcommand(bytearray(b'\xBA\x0A\x02') + bytes.fromhex(self.sector) + bytes.fromhex(self.keyType) + bytes.fromhex('FFFFFFFFFFFF'))
				response	= self.cleancommand(response, '0xbd')
				logging.info("Write Master Key")

				response = self.writemasterkey()

				if response:	return True

	def verify_command(self, response, verify_hex, verify_status):
		return True
		if not response: return False
		if response==b"": return False

		if hex(response[0]) == verify_hex:
			status	= hex(response[3])

			if status == verify_status:
				return	True
			else:
				logging.error(f"status: {status} - verify_status:{verify_status}")

		else:
			logging.error(f"hex(response[0]): {hex(response[0])} - verify_hex:{verify_hex}")

		return	False

	def inicializevalueblock(self, value:list) -> bytearray:
		WRITECMD	= bytearray(b'\xBA\x13\x04') + bytes.fromhex(self.bloque)

		for k in value:	WRITECMD.append(k)

		response	= self.sendcommand(WRITECMD, value)
		logging.info(response)

		return	self.verify_command(response, '0xbd', '0x0')

	def writemasterkey(self) -> bytearray:		return	self.verify_command(self.sendcommand(bytearray(b'\xBA\x09\x07' + bytes.fromhex(self.sector) +  bytes.fromhex(self.key))), '0xbd', '0x0')

	def downloadkeyintoreader(self) -> bool:	return	self.verify_command(self.sendcommand(bytearray(b'\xBA\n\x12') + bytes.fromhex(self.sector) + bytes.fromhex(self.keyType) + bytes.fromhex(self.key)), '0xbd', '0x0')

	def loginSectorStoredKey(self) -> bool:		return	self.verify_command(self.sendcommand(bytearray(b'\xBA\x04\x13') + bytes.fromhex(self.sector) + bytes.fromhex(self.keyType) + bytes.fromhex(self.key)), '0xbd', '0x2')


	def readvalueblock(self) -> Tuple:
		rsp_verify	= self.loginSector

		if rsp_verify:
			response	= self.sendcommand(bytearray(b'\xBA\x03\x05') + bytes.fromhex(self.bloque))
			rsp_verify	= self.verify_command(response, '0xD', '0x0')

			if rsp_verify:
				return	response[4:], True
			else:
				logging.error(rsp_verify)

		else: logging.error(rsp_verify)

		if not rsp_verify:	return	None, False

	def readdatablock(self) -> Tuple:
		rsp_verify	= self.loginSector()
		logging.info(f"verify:{rsp_verify}")
		if rsp_verify:
			response	= self.sendcommand(bytearray(b'\xBA\x03\x03') + bytes.fromhex(self.bloque))
			print("readdatablock",response)
			rsp_verify	= self.verify_command(response, '0xbd', '0x0')
			logging.info(response[4:])

		if rsp_verify:
			return list(bytes(response[4:]))
		else:
			return []

	def writedatablock(self, value:list) -> bytearray:
		try:
			rsp_verify	= False

			response	= self.sendcommand(bytearray(b'\xBA\x13\x04') + bytes.fromhex(self.bloque), value)
			print ("writedatablock",response)
			if response==b"":
				sleep(0.1)
				response = self.sendcommand(bytearray(b'\xBA\x13\x04') + bytes.fromhex(self.bloque), value)
				print("writedatablock", response)

			rsp_verify	= self.verify_command(response, '0xbd', '0x0')

		except Exception as err:	logging.error(err)
		finally:					return	rsp_verify




class lector_sl025(): # -----------------------------------------------------> MANEJADOR SERIAL VIP/MENSUALIDAD/ESPACIALES
	def __init__(self):	logging.info(self.__class__.__name__)

	def start(self, callback, port_serial, key) -> None:
		logging.info(f"	port {port_serial} - key {key}")

		self._callback		= callback
		self.port_serial	= port_serial
		self.key			= key

		threading.Thread(target	= self.listen_port).start()

	def getserialport(self, port_serial: str) -> serial:
		self.ser = None
		try:
			self.ser = serial.Serial(
				port		= port_serial,
				baudrate	= 9600,
				parity		= serial.PARITY_NONE,
				stopbits	= serial.STOPBITS_ONE,
				bytesize	= serial.EIGHTBITS,
				timeout		= 0.2
			)
		except Exception as err:	logging.error(err)


	def select_card(self, mode=0):
		response	= self.sendcommand(bytearray(b'\xBA\x02\x01'))

		if hex(response[0]) == '0xbd':
			status	= hex(response[3])

			if status == '0x0':
				length		= response[1]
				ttype		= hex(response[length])
				uid			= response[4:length].hex()  # As the different cards have different UID lengths, we need to parse the UID differently
				keySerial	= int(uid[6:8]+uid[4:6]+uid[2:4]+uid[0:2], 16)

				if mode == 0:	return ({'uid': uid}, keySerial)
				else:		    return ({'uid': uid, 'type': hex(response[length]), 'literalType': ttype}, 0)

		return	None, -1

	def CRC(self, Data: bytes) -> bytes:
		lrc	= 0
		for v in Data:	lrc ^= v
		return	lrc

	def sendcommand(self, cmd:bytearray, value:list = None):
		if value:
			for k in value:	cmd.append(k)

		cmd.append(self.CRC(cmd))

		self.ser.write(cmd)

		return	self.ser.readline()

	def listen_port(self):
		self.getserialport(self.port_serial)

		global last_token_sl025m
		last_token_sl025m = ""
		status = True

		while True:
			try:
				id	= self.select_card()

				if id[1] != -1 and status:
					status = False
					last_token_sl025m = id[1]
					self._callback({"class":"card", "data": id[1]})
					sleep(2)

				else: status = True

			except Exception as err:
				logging.warning(err)

				self._callback({"class":"alert", "data": {"title": "LECTOR SL025","subtitle": "ERROR DE CONEXI�N"}})
				self.getserialport(self.port_serial)

			sleep(1)

if __name__ == '__main__':
	from datetime					import datetime

	logging.info(f"==========> {str(datetime.now())[:-7]} <-------------------------------------->")

	from time						import time
	logging.info(f"==========> {str(datetime.now())[:-7]} <-------------------------------------->")

	SL025M  = Lector_SL025()
	SL025M.start("/dev/ttyCardReader", "AA", "654853505267", "00","01")

	data=[50, 174, 124, 10, 230, 211, 224, 38, 230, 210, 252, 176, 231, 210, 224, 1]
	id=SL025M.select_card()
	print (id)
	resp=SL025M.loginSector()
	print("login", resp)
	resp=SL025M.writedatablock(data)
	print(resp)
	datar=SL025M.readdatablock()
	print(data)
	print (list(bytes(datar)))


	sys.exit(0)

	while True:

		logging.info(f"==========> {str(datetime.now())[:-7]} <-------------------------------------->")

		id		= SL025M.select_card()
		resp_readdatablock	= SL025M.readdatablock()
		resp_parqueadero	= [50, 63, 181, 15, 38, 198, 91, 37, 38, 198, 62, 179, 39, 198, 128, 1]
		resp_writedatablock	= SL025M.writedatablock(resp_parqueadero)
		resp_readdatablock	= SL025M.readdatablock()

		if resp_parqueadero == resp_parqueadero:	logging.info(f"---------->	Marcacion correcta")
		else:
			logging.info(f"Lo que se debio marcar:			{resp_parqueadero}")
			logging.info(f"Lo que se encuentra marcado:	{resp_parqueadero}")

		logging.info(f"----------------------------------------------------->")

		sleep(5)