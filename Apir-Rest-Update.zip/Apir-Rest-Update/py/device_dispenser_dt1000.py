from time import sleep
import usb.core
import logging
import threading

from sys import platform

VENDOR_ID		= 0x0483 # VUSB VID
PRODUCT_ID		= 0xA058 # VUSB PID for HID
INTERFACE		= 0
WRITE_TIMEOUT	= 10 * 1000
DATA_LENGTH		= 63

class td1000:
	def __init__(self):	logging.info(self.__class__.__name__)

	def start(self) -> bool:
		try:
			status = True
			self._validate_device()

	
			self._initialize()
	
			self._configure_schedule()

		except Exception as err:
			logging.error(err)
			status	= False

		finally: return status

	def _validate_device(self):
		try:
			if self._device is None:
				self._device.ctrl_transfer(0xA1, 0x01, 0x300, 0x00, 0x08) 
		except:
			self._device = None

		if self._device is None:
			self._device = usb.core.find(idVendor=VENDOR_ID, idProduct=PRODUCT_ID)

			if self._device is None:	raise Exception('Error opening device')
			
			if platform == "linux" or platform == "linux2":
				if self._device.is_kernel_driver_active(INTERFACE) is True:
					logging.info(f"Interface: {INTERFACE}")
					self._device.detach_kernel_driver(INTERFACE)        
					usb.util.claim_interface(self._device, INTERFACE)        

			self._device.set_configuration()

	def _initialize(self):
		data_to_send = self._get_send_bytes(0x49, 0x30)

		self._device.write(0x01, data_to_send) 

		bytes_read	= self._device.read(0x81, DATA_LENGTH, WRITE_TIMEOUT)
		st1			= bytes_read[7]
		st2			= bytes_read[8]

		if st1 != 0x30 or st2 != 0x30:	raise Exception('Error in configure_schedule card command: ' + str(st1) + str(st2))

	def _configure_schedule(self):
		eject_length		= 70    # Default 100mm, we change it to 70 mm in order to avoid throwing the card when it's ejected
		eject_length_high	= (eject_length >> 8) & 0xFF
		eject_length_low	= eject_length & 0xFF

		eject_speed			= 800 # Default
		eject_speed_high	= (eject_speed >> 8) & 0xFF
		eject_speed_low		= eject_speed & 0xFF

		tray_count			= 1  # Default
		tray_count_high		= (tray_count >> 8) & 0xFF
		tray_count_low		= tray_count & 0xFF

		data_config		= [0x01, 0x31, eject_length_high, eject_length_low, eject_speed_high, eject_speed_low, 0x31, tray_count_high, tray_count_low]
		data_to_send	= self._get_send_bytes(0x54, 0x30, data_config)

		self._device.write(0x01, data_to_send) 
		bytes_read = self._device.read(0x81, DATA_LENGTH, WRITE_TIMEOUT)
		
		st1 = bytes_read[7]
		st2 = bytes_read[8]

		if st1 != 0x30 or st2 != 0x30:	raise Exception('Error in configure_schedule card command: ' + str(st1) + str(st2))





	def check_connection(self):
		try:						self._validate_device()
		except Exception as err:	logging.info(err)
		else:						logging.info("OK")

	def take_card(self):
		self._validate_device()
		data_to_send = self._get_send_bytes(0x44, 0x35)

		self._device.write(0x01, data_to_send) 
		bytes_read	= self._device.read(0x81, DATA_LENGTH, WRITE_TIMEOUT)
		
		st1 = bytes_read[7]
		st2 = bytes_read[8]

		if st1 != 0x30 or st2 != 0x30:
			raise Exception('Error in rf ready card command: ' + str(st1) + str(st2))

		# logging.info('Done!')


	def dispense_card(self):
		self._validate_device()
		data_to_send = self._get_send_bytes(0x44, 0x33)

		self._device.write(0x01, data_to_send) 
		bytes_read = self._device.read(0x81, DATA_LENGTH, WRITE_TIMEOUT)
		
		st1 = bytes_read[7]
		st2 = bytes_read[8]

		if st1 != 0x30 or st2 != 0x30:
			raise Exception('Error in eject card command' + str(st1) + str(st2))

		# logging.info('Done!')


	def reject_card(self):
		self._validate_device()
		data_to_send = self._get_send_bytes(0x44, 0x34)

		self._device.write(0x01, data_to_send) 
		bytes_read = self._device.read(0x81, DATA_LENGTH, WRITE_TIMEOUT)
		
		st1 = bytes_read[7]
		st2 = bytes_read[8]

		if st1 != 0x30 or st2 != 0x30:
			raise Exception('Error in reject card command' + str(st1) + str(st2))

		#logging.info('Done!')


	def get_status(self):
		while True:
			data_to_send = self._get_send_bytes(0x52, 0x30)

			self._device.write(0x01, data_to_send) 
			bytes_read = self._device.read(0x81, DATA_LENGTH, WRITE_TIMEOUT)

			st1 = bytes_read[7]
			st2 = bytes_read[8]

			if st1 != 0x30 or st2 != 0x30:	logging.warning(f"status no identificado")
			else:
				logging.debug("".join("%02x " % b for b in bytes_read))

				bottom_tray_sensor	= (bytes_read[9] >> 1) & 0x01
				top_tray_sensor		= (bytes_read[9]) & 0x01

				if not bottom_tray_sensor:	tray_status = 'empty'
				elif not top_tray_sensor:	tray_status = 'near-end'
				else:						tray_status = 'loaded'
			
				# Now, we will get the information of the other sensors
				sensor_byte_rail	= bytes_read[13]
				sensor_byte_feed	= bytes_read[14]
				
				rail_out	= sensor_byte_rail & 0x01
				rail_inlet	= (sensor_byte_rail >> 1) & 0x01
				rail_rf		= (sensor_byte_rail >> 4) & 0x01

				feed_roller_1	= sensor_byte_feed & 0x01
				feed_roller_2	= (sensor_byte_feed >> 1) & 0x01

				feed_plate_position_1	= (sensor_byte_feed >> 2) & 0x01
				feed_plate_position_2	= (sensor_byte_feed >> 3) & 0x01
				feed_plate_position_3	= (sensor_byte_feed >> 4) & 0x01
				feed_plate_position_4	= (sensor_byte_feed >> 5) & 0x01
				feed_plate_left_end		= (sensor_byte_feed >> 6) & 0x01
				feed_plate_right_end	= (sensor_byte_feed >> 7) & 0x01

				logging.info({
					'trayStatus': tray_status,
					'railOut': rail_out,
					'railInlet': rail_inlet,
					'railRF': rail_rf,
					'feedRoller1': feed_roller_1,
					'feedRoller1': feed_roller_2,
					'feedPlatePosition1': feed_plate_position_1,
					'feedPlatePosition2': feed_plate_position_2,
					'feedPlatePosition3': feed_plate_position_3,
					'feedPlatePosition4': feed_plate_position_4,
					'feedPlateLeftEnd': feed_plate_left_end,
					'feedPlateRightEnd': feed_plate_right_end,
				})

			sleep(1)


	def select_card(self):
		self._validate_device()
		self._power_off_rf()
		self._power_on_rf()
		self._idle_request_rf()
		card_id = self._anti_collision_rf()

		return card_id

	# Writes 16 bytes block
	# NOTE: Before calling this function, you should have been called select_card()
	def write_card(self, key, sector, address, data):
		self._validate_device()
		self._auth_key_rf(key, sector)
		
		mifare_block = sector * 4 + address
		rf_write = self._get_rf_data_bytes(0x28, [mifare_block, *data])

		data_to_send = self._get_send_bytes(0x43, 0x30, rf_write)
		# logging.info("".join("%02x " % b for b in data_to_send))

		self._device.write(0x01, data_to_send) 
		bytes_read = self._device.read(0x81, DATA_LENGTH, WRITE_TIMEOUT)

		st1 = bytes_read[7]
		st2 = bytes_read[8]

		if st1 != 0x30 or st2 != 0x30:
			raise Exception(f'Error write_card command {st1} {st2}')
		
		# RF STX starts from 13
		# logging.info("".join("%02x " % b for b in bytes_read))
		if bytes_read[16] != 0x00:
			raise Exception(f'write_card response not ok {bytes_read[16]}')


	# Reads 16 bytes block
	# NOTE: Before calling this function, you should have been called select_card()
	def read_card(self, key, sector, address):
		self._validate_device()
		self._auth_key_rf(key, sector)

		# Read data block
		mifare_block = sector * 4 + address
		rf_read = self._get_rf_data_bytes(0x27, [mifare_block])

		data_to_send = self._get_send_bytes(0x43, 0x30, rf_read)
		# logging.info("".join("%02x " % b for b in data_to_send))

		self._device.write(0x01, data_to_send) 
		bytes_read = self._device.read(0x81, DATA_LENGTH, WRITE_TIMEOUT)

		st1 = bytes_read[7]
		st2 = bytes_read[8]

		if st1 != 0x30 or st2 != 0x30:
			raise Exception(f'Error read_card command {st1} {st2}')
		
		# RF STX starts from 13
		# logging.info("".join("%02x " % b for b in bytes_read))
		if bytes_read[16] != 0x00:
			raise Exception(f'read_card response not ok {bytes_read[16]}')

		mifare_bytes = []
		for i in range(17, 17 + 16):
			mifare_bytes.append(bytes_read[i])

		return mifare_bytes


	def _power_on_rf(self):
		rf_power_on = self._get_rf_data_bytes(0x10)

		data_to_send = self._get_send_bytes(0x43, 0x30, rf_power_on)
		# logging.info("".join("%02x " % b for b in data_to_send))

		self._device.write(0x01, data_to_send) 
		bytes_read = self._device.read(0x81, DATA_LENGTH, WRITE_TIMEOUT)

		st1 = bytes_read[7]
		st2 = bytes_read[8]

		if st1 != 0x30 or st2 != 0x30:
			raise Exception(f'Error power_on_rf command {st1} {st2}')
		
		# RF STX starts from 13
		# logging.info("".join("%02x " % b for b in bytes_read))
		if bytes_read[16] != 0x00:
			raise Exception(f'power_on_rf response not ok {bytes_read[16]}')

	
	def _power_off_rf(self):
		rf_power_off = self._get_rf_data_bytes(0x11)

		data_to_send = self._get_send_bytes(0x43, 0x30, rf_power_off)
		# logging.info("".join("%02x " % b for b in data_to_send))

		self._device.write(0x01, data_to_send) 
		bytes_read = self._device.read(0x81, DATA_LENGTH, WRITE_TIMEOUT)

		st1 = bytes_read[7]
		st2 = bytes_read[8]

		if st1 != 0x30 or st2 != 0x30:
			raise Exception(f'Error rf_power_off command {st1} {st2}')
		
		# RF STX starts from 13
		# logging.info("".join("%02x " % b for b in bytes_read))
		if bytes_read[16] != 0x00:
			raise Exception(f'rf_power_off response not ok {bytes_read[16]}')

	def _idle_request_rf(self):
		# Sends select command
		rf_idle_request = self._get_rf_data_bytes(0x21)
		data_to_send = self._get_send_bytes(0x43, 0x30, rf_idle_request)
		
		self._device.write(0x01, data_to_send) 
		bytes_read = self._device.read(0x81, DATA_LENGTH, WRITE_TIMEOUT)

		st1 = bytes_read[7]
		st2 = bytes_read[8]

		if st1 != 0x30 or st2 != 0x30:
			raise Exception(f'Error in idle_request_rf command {st1} {st2}')
		
		# RF STX starts from 13
		if bytes_read[16] != 0x00:
			raise Exception(f'idle_request_rf response not ok {bytes_read[16]}')


	def _anti_collision_rf(self):
		# Sends select command
		rf_select = self._get_rf_data_bytes(0x3D)
		data_to_send = self._get_send_bytes(0x43, 0x30, rf_select)
		
		self._device.write(0x01, data_to_send) 
		bytes_read = self._device.read(0x81, DATA_LENGTH, WRITE_TIMEOUT)

		st1 = bytes_read[7]
		st2 = bytes_read[8]

		if st1 != 0x30 or st2 != 0x30:
			raise Exception(f'Error in anti_collision_rf command {st1} {st2}')

		# RF STX starts from 13
		if bytes_read[16] != 0x00:
			raise Exception(f'anti_collision_rf response not ok {bytes_read[16]}')

		len_high = bytes_read[14]
		len_low = bytes_read[15]
		len = len_low + len_high * 256

		if len < 2:
			raise Exception(f'Invalid len obtained in anti_collision function: {len}')

		card_id = 0
		for i in range(18, 18 + len - 2):
			card_id += bytes_read[i] * pow(256, i - 18)

		return card_id
	

	def _auth_key_rf(self, key, sector):
		# Loading key A
		data = [0x00, *key, sector]
		rf_auth_key = self._get_rf_data_bytes(0x30, data)
		data_to_send = self._get_send_bytes(0x43, 0x30, rf_auth_key)
		
		self._device.write(0x01, data_to_send) 
		bytes_read = self._device.read(0x81, DATA_LENGTH, WRITE_TIMEOUT)

		st1 = bytes_read[7]
		st2 = bytes_read[8]

		if st1 != 0x30 or st2 != 0x30:
			raise Exception(f'Error in _auth_key_rf command {st1} {st2}')

		# RF STX starts from 13
		if bytes_read[16] != 0x00:
			raise Exception(f'_auth_key_rf response not ok {bytes_read[16]}')


	def _get_send_bytes(self, command, subcommand, data=[]):
		total_length = 2 + len(data) 
		len_low = total_length & 0xFF
		len_high = (total_length >> 8) & 0xFF

		# 0x4F -> Send command to host to module
		# 0x02 -> STX
		bytes_to_send = [0x4F, 0x02, len_high, len_low, command, subcommand]
		for byte in data:
			bytes_to_send.append(byte)

		# 0x03 -> ETX
		bytes_to_send.append(0x03)

		# Calculate BCC 
		# XOR each byte with the result of the previous XOR
		# https://bcc.beyerleinf.de/
		bcc = 0
		for i in range(2, len(bytes_to_send)):
			byte = bytes_to_send[i]
			bcc = bcc ^ byte
		bytes_to_send.append(bcc)

		# We need to fill with zeros, otherwise the comamnd will not work
		while len(bytes_to_send) < DATA_LENGTH:
			bytes_to_send.append(0x00)

		return bytes_to_send
	

	def _get_rf_data_bytes(self, command, data=[]):
		total_length = 1 + len(data) 
		len_low = total_length & 0xFF
		len_high = (total_length >> 8) & 0xFF

		rf_bytes = [0x02, len_high, len_low, command]
		for byte in data:
			rf_bytes.append(byte)

		lrc = 0
		for i in range(1, len(rf_bytes)):
			byte = rf_bytes[i]
			lrc = lrc ^ byte
		rf_bytes.append(lrc)

		return rf_bytes
	


if __name__ == '__main__':
	key			= [101, 72, 83, 80, 82, 103]  # corpaul key
	new_data	= [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
	sector		= 0
	address		= 1

	def main():
		logging.basicConfig(format	= "%(asctime)s [%(levelname)s]	%(module)s:%(lineno)d:	%(message)s" , level	= logging.DEBUG)
     
		logging.info('Initializing main function')
		dispenser = td1000()

		dispenser.start()
		#threading.Thread(target	= dispenser.get_status).start()

		command = input('Select a command to send for the dispenser: ')
		while command != 'quit':
			try:
				if command == 'take':		dispenser.take_card() # MANDAR TARJETA A LA LECTORA
				if command == 'dispense':	dispenser.dispense_card()
				if command == 'status':		logging.info(dispenser.get_status())  
				if command == 'reject':		logging.info(dispenser.reject_card()) # RECICLAR
				if command == 'mfselect':	logging.info(dispenser.select_card())
				if command == 'mfread':		logging.info(dispenser.read_card(key, sector, address))
				if command == 'mfwrite':	dispenser.write_card(key, sector, address, new_data)

			except Exception as e:	logging.info(f'Exception in command execution: {e}')
			finally:				command = input('Select a command to send for the dispenser: ')

		logging.info('Finish')

	main()