import sys

from escpos.printer import Usb
from time import sleep

import logging
import threading


ESC = b"\x1b"
GS = b"\x1d"

PAPERCUTFULL        = ESC + b"i" + b"\x00"
PAPERCUTPARTIAL     = ESC + b"m" + b"\x01"
PAPERCUTPARTIALOP   = ESC + b"n" + b"\x01"


class nippon_printer:
	printer=None
	last_state=None
	PRINTERSTATUS = {
		0: "Impresora lista",
		1: "Impresora baja de papel",
		2: "Puerta abierta",
		3: "Puerta abierta y baja de papel",
		4: "Feed sin Papel",
		5: "Sin papel",
		6: "Puerta abierta y sin papel en feed",
		7: "Puerta abierta y sin papel",
		64: "Inicio de impresion",
		80: "Atasco de papel"
	}

	def __init__(self):
		logging.info(f"CLASS: {self.__class__.__name__}")

	def start(self, callback, id_vendor, id_product, retract=0): #retract: 0-,manual, 1-auto

		self._callback	= callback
		self.id_vendor	= id_vendor
		self.id_product = id_product
		self.finish		= False
		self.retract=retract
		self.noPaper    = False


	def disconnect(self):
		self.finish=True
		self.printer.close()
		self.printer=None

	def connect(self):
		resp=0
		try:
			self.printer = Usb(self.id_vendor,  self.id_product, 0, out_ep=0x01)

			resp=0
		except Exception as exc:
			self.printer (f"Printer connect error: {exc}", exc)
			resp=-1

		logging.info (f"Printer Connect: {self.printer}")
		if self.printer:
			try:
				if self.printer.is_online():
					self.printer.set(font=1, align='left', underline=0, width=1, height=1, invert=False, smooth=True,
									 flip=False, double_width=False, double_height=False, custom_size=True)
					self.printer._raw(b'\x1D\x76\x00') #Auto-transmitting status
					if self.retract==1:
						self.printer._raw(b'\x1B\x68\x02') #Presenter mode: x02: for enabling retraction
					else:
						self.printer._raw(b'\x1B\x68\x03') #Presenter mode: x01: for disabled retraction

					self.finish=False
					self.listen()
					resp=0
				else:
					self.status(80)
					self.printer.close()
					self.printer=None
					resp=80
			except Exception as err:
				logging.info(f"printer error:{err}")
				self.finish=True
				self.printer.close()
				self.printer=None
				resp=99
		else:
			resp=-1
		return resp


	def listen(self):
		self.t_read_port	= threading.Thread(target	= self.read_state)
		self.t_read_port.start()

	def read_state(self):
		logging.info("Listen printer")
		while not self.finish:
			if self.printer:
				if self.printer.is_online():
					read  = self.printer._read()
					self.status(read[0])
				else:
					self.status(80)
				sleep(0.5)
			else:
				break
		self.printer.close()


	def cut(self, mode	= "FULL", feed	= True):
		if self.printer:
			if self.printer.is_online():
				mode = mode.upper()
				if mode not in ("FULL", "PART"):    raise ValueError("Mode must be one of ('FULL', 'PART')")

				if mode == "PART":
					self.printer._raw(PAPERCUTPARTIAL)
				if mode == "FULL":
					self.printer._raw(PAPERCUTFULL)
				if mode == "PART2":
					self.printer._raw(PAPERCUTPARTIALOP)
				if mode == "LOSE":
					self.printer._raw(b"\x0A\x0A\x0A\x0A\x0A\x0A\x1B\x69")
			else:
				self.status(80)


	def retraction(self):
		ret=0
		if self.printer:
			try:
				if self.printer.is_online():
					read  = self.printer._read()
					if read[0] == 65: #paper in presenter
						self.printer._raw(b'\x1B\x72\x30\x00') #Command for retraction
				else:
					self.status(80)
			except Exception as exc:
				ret=80

	def status(self, state):
		if self.last_state!=state:
			self.last_state=state
			self._callback({'class': self.__class__.__name__, 'data': self.PRINTERSTATUS.get(state, state)})



	def print(self, qrCode = "", text_pre = "", text_pos = "", cut="FULL"):
		resp=None
		logging.info("Print")
		if not self.printer:
			resp=self.connect()
			logging.info("Printer Reconnected")

		if self.printer:
			try:
				if self.printer.is_online():
					logging.info(f"QR: {qrCode}")
					logging.info(f"TextoPre: {text_pre}")
					logging.info(f"TextoPos: {text_pos}")

					if len(text_pre) != 0:  self.printer.text(text_pre)
					if len(qrCode) != 0:    self.printer.qr(qrCode, size	= 8, center	= True, impl	= "bitImageColumn")
					if len(text_pos) != 0:  self.printer.text(text_pos)

					self.printer.textln("")
					self.printer.textln("")
					self.printer.textln("")
					self.cut(cut)
					resp= 0
				else:
					self.status(80)
					self.finish=True
					resp= 80
			except Exception as err:
				logging.info(f"printer error:{err}")
				self.finish=True
				if self.printer:
					self.printer.close()
					self.printer=None
				resp=99

		return resp

if __name__=="__main__":
	def callback(callback):
		print(callback)

	response_printer = nippon_printer()
	response_printer.start(callback, 0x1051, 0x1000)
	sleep(1)
	print (response_printer.print("CODIGO QR QUE HACE RING Y HACE RING", "TIQUETE PRE QUE HACE RING Y HACE RING", "TIQUETE PRE QUE HACE RING Y HACE RING"))
	sleep(5)
	print (response_printer.print("CODIGO QR QUE HACE RING Y HACE RING", "TIQUETE PRE QUE HACE RING Y HACE RING", "TIQUETE PRE QUE HACE RING Y HACE RING"))
	sleep(2)
	print (response_printer.retraction()) #Call for retraction after time.sleep(seconds)
	#sys.exit(0)