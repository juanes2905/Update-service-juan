import os
import logging
import threading
import time
from pathlib import Path
from logging.handlers import TimedRotatingFileHandler
from flask import Flask, jsonify, request
from py.device_np_printer import nippon_printer
from py.device_SL025M_v2 import Lector_SL025, serial_ports  
from py.device_dispenser_dt1000 import td1000

class DeviceManager:
    def __init__(self):
        self.directorio = os.path.dirname(os.path.realpath(__file__))
        self.setup_logging()
        self.impresora = None
        
        self.lectora = None
        self.lectora_status = {"connected": False, "port": None}

        self.lock = threading.Lock()
        
        # Inicializaciones de clases para los diferentes dispositivos
        self.iniciar_impresora()
        threading.Thread(target=self.detect_reader_port, daemon=True).start()
        self.dispenser = None  # No iniciar el dispensador aquí

        self.app = Flask(__name__)
        self.setup_routes()

    def setup_logging(self):
        # Configuración para crear y guardar archivo de logs
        os.makedirs(self.directorio + "/logs", exist_ok=True)
        files_logs = os.path.join(self.directorio, "logs", "logs.log")
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s [%(levelname)s] %(module)s:%(lineno)d %(funcName)s | %(message)s",
            datefmt='%Y-%m-%d %H:%M:%S',
        )
        handler = TimedRotatingFileHandler(files_logs, when="midnight", interval=1)
        handler.suffix = "%Y%m%d"
        logging.getLogger().addHandler(handler)

    def callback_printer(self, status):
        if status == "SUCCESSFULL":
            logging.info("La impresión se completó correctamente.")


    def callback_reader(self, card_data):
        logging.info(f"Tarjeta RFID detectada: {card_data}")

    def callback_dispenser(self, operation):
        logging.info(f"Operación del dispensador completada: {operation}")

    def iniciar_impresora(self):
        try:
            logging.info("<-------------------------- INICIANDO IMPRESORA --------------------------->")
            self.impresora = nippon_printer()
            self.impresora.start(self.callback_printer, 0x1051, 0x1000)
        except Exception as e:
            self.impresora = None
            logging.error(f"Error al iniciar impresora: {e}")

    def detect_reader_port(self):
        logging.info("<----------------- INICIANDO LECTORA ------------------------>")
        while not self.lectora_status["connected"]:
            ports = serial_ports()
            for port in ports:
                try:
                    with self.lock:
                        self.lectora = Lector_SL025()
                        self.lectora.start(port, "AA", "654853505267", "00", "01")
                        if self.lectora.ser:
                            logging.info(f"RESPONSE: Lectora detectada en el puerto {port}")
                            self.lectora_status = {"connected": True, "port": port}
                            return
                except Exception as e:
                    logging.error(f"ERROR: Error al conectar con el puerto {port}: {e}")
            self.lectora = None
            logging.error(f"ERROR: No hay lectora conectada. Reintentando en 5 segundos... {self.lectora_status}")
            time.sleep(5)

    def iniciar_dispenser(self):
        logging.info("<----------------------- INICIANDO CARRO -------------------------->")
        try:
            self.dispenser = td1000()
            self.dispenser.start()
        except Exception as e:
            self.dispenser = None
            logging.error(f"Error: No se pudo conectar con el carro {e}")

    def close_reader_port(self):
        if self.lectora and self.lectora.ser:
            try:
                self.lectora.close()
                logging.info("Lectora desconectada y puerto cerrado")
            except Exception as e:
                logging.error(f"Error al cerrar el puerto de la lectora: {e}")

    def close_printer(self):
        if self.impresora:
            try:
                self.impresora.disconnect()
                logging.info("Impresora desconectada")
            except Exception as e:
                logging.error(f"Error al desconectar la impresora: {e}")

    def close_dispenser(self):
        if self.dispenser:
            try:
                self.dispenser._validate_device()
                logging.info("Dispensador desconectado")
            except Exception as e:
                logging.error(f"Error al desconectar el dispensador: {e}")

    def setup_routes(self):
        @self.app.route('/')
        def pag_not_found():
            return "<h1 style='text-align: center; font-size: 40px; position: absolute; top: 40%; left: 50%; transform: translate(-50%, -50%);'>PAGE NOT FOUND</h1>"

        @self.app.route('/sdk', methods=['POST'])
        def print_tests():
            status = 400
            error_data = "Unknown error"

            if not self.lectora_status["connected"]:
                error_data = "No hay conexión con la lectora"
                logging.info(f"RESPONSE: {error_data}")
                return jsonify([{"error": status, "errorData": error_data}]), status

            if request.method == 'POST':
                request_data = request.get_json() if request.is_json else request.form.to_dict()
                command = request_data.get("command")

                if command == "PRINTER":
                    status, error_data = self.handle_printer_command(request_data)
                elif command == "READER":
                    status, error_data = self.handle_reader_command()
                elif command == "DISPENSER":
                    status, error_data = self.handle_dispenser_command()
                else:
                    error_data = "Comando no reconocido"

            return jsonify([{"error": status, "errorData": error_data}]), status

    def handle_printer_command(self, data):
        if self.impresora:
            try:
                if data.get("data"):
                    logging.info(f"Se imprime {data['data']}")
                    self.impresora.print(text_pre=data["data"])
                    logging.info("SUCCESSFULL: Impresión exitosa")
                    return 200, "Impresión exitosa"
                else:
                    logging.info("ERROR: Error data sin contenido")
                    return 400, "Error data sin contenido"
            except Exception as e:
                logging.error(f"Error: {e}")
                return 500, str(e)
        else:
            logging.info("ERROR: Impresora no conectada")
            return 500, "Error impresora no conectada"

    def handle_reader_command(self):
        if self.lectora:
            try:
                card_data, serial = self.lectora.select_card()
                if card_data and serial != -1:
                    return 200, f"Datos de la tarjeta RFID {card_data}"
                elif serial == -1:
                    logging.info("RESPONSE: No hay tarjeta en la lectora")
                    return 400, "No hay tarjeta en la lectora"
                else:
                    logging.error("RESPONSE: Error al leer la tarjeta")
                    return 500, "Error al leer la tarjeta, verifique la conexión de la lectora reinicie por favor"
            except Exception as e:
                logging.error(f"ERROR: {e}")
                return 500, str(e)
        else:
            logging.error("ERROR: Lectora no conectada")
            return 500, "Error, lectora no conectada"

    def handle_dispenser_command(self):
        if not self.dispenser:
            self.iniciar_dispenser()  # Iniciar el dispensador si aún no está iniciado
        if self.dispenser:
            try:
                thread = threading.Thread(target=self.dispenser_thread)
                thread.start()
                logging.info("SUCCESS: Operacion realizada con exito")
                return 200, "Operacion realizada con exito"
            except Exception as e:
                logging.error(f"ERROR: {e}")
                return 500, str(e)
        else:
            logging.error("ERROR: Dispensador no conectado")
            return 500, "Dispensador no conectado"
        
    def dispenser_thread(self):
        try:
            self.dispenser.take_card()
            logging.info("SUCCESS: Tarjeta en lectora")

            # Simulamos un tiempo de espera de 10 segundos antes de dispensar la tarjeta
            time.sleep(3)
           
            self.dispenser.dispense_card()
            logging.info("SUCCESS: Tarjeta dispensada")
        except Exception as e:
            logging.error(f"ERROR: {e}")

    def run(self):
        self.app.run(debug=True, host="0.0.0.0", port=8000)

    def stop(self):
        self.close_printer()
        self.close_dispenser()
        logging.info("Todos los dispositivos se han desconectado")

if __name__ == "__main__":
    manager = DeviceManager() # SE INICIA LA CLASE DEL SERVICIO
    try:
        manager.run()
    except KeyboardInterrupt: # SE INTERRUMPE POR MEDIO DE TECLADO
        manager.stop()